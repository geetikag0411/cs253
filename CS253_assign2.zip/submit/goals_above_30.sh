#!/bin/bash

# check if input file exists
if [ ! -f "$1" ]; then
    echo "Error: File $1 not found."
    exit 1
fi
# check if file 2 exist
if [ ! -f "$2" ]; then
    echo "Error = File $2 not found."
    exit 1
fi

# extract player details and write to output file
awk -F, '$2>30 && $16>=1' "$1" > "$2"

# In awk command, $2(age) refers to the value in the 2nd column and $16 refers to the value in the 16th column, both of which are separated by commas due to the -F, option.

# The condition '$2>30 && $16>=1' checks if the age (in column 2) is greater than 30 and the total number of goals scored (in column 16) is greater than or equal to 1.
echo "We have successfully written into the second file"

#to run
# chmod +x goals_above_30.sh
#./goals_above_30.sh input.csv out2.csv