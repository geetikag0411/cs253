# if [ ! -f "$1" ]; then
#     echo "Error: File $1 not found."
#     exit 1
# fi

# if [ ! -f "$2" ]; then
#     echo "Error: File $2 not found."
#     exit 1
# fi
# echo "full_name, nationality,
# position,goals_overall">>"$2"
# #introducing a fifth column, andmaking its val 1 if forward,2 if Midfielder,3 if Defender and else 4
#   awk -F',' 'NR>1 {print $1","$12","$7","$16}' "$1" | sort -t',' -k4nr -k3 | awk '!seen[$1,$2,$3]++' | 
#  awk -F',' 'BEGIN { OFS = "," } { print $0, ($3 == "Forward" ? 1 : ($3 == "Midfielder" ? 2 : ($3 == "Defender" ? 3 : 4))) }' | sort -t',' -k4nr -k5n -k3 > "$2"

# cut -d ',' -f 1-4 "$2" > temp.csv && mv temp.csv "$2"
# #removing last appended column

# #to run
# # chmod +x players.sh
# #./players.sh input.csv out4.csv


#!/bin/bash

# Check if two file names are provided
if [ $# -ne 2 ]; then
    echo "Usage: players.sh input_file output_file"
    exit 1
fi

# Check if the input file exists
if [ ! -f "$1" ]; then
    echo "Error: File $1 not found."
    exit 1
fi

# Output the header line to a temporary file
echo "full_name,nationality,position,goals_overall" > temp.csv

# Introduce a fifth column, and make its value 1 if forward, 2 if Midfielder, 3 if Defender and else 4
awk -F',' 'NR>1 {print $1","$12","$7","$16}' "$1" | sort -t',' -k4nr -k3 | awk '!seen[$1,$2,$3]++' | awk -F',' 'BEGIN { OFS = "," } { print $0, ($3 == "Forward" ? 1 : ($3 == "Midfielder" ? 2 : ($3 == "Defender" ? 3 : 4))) }' | sort -t',' -k4nr -k5n -k3 >> temp.csv

# Rename the temporary file to the output file
mv temp.csv "$2"

# Cut the appended column from the output file
cut -d ',' -f 1-4 "$2" > temp.csv && mv temp.csv "$2"

#to run
# chmod +x players.sh
#./players.sh input.csv out4.csv  