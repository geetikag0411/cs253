#!/bin/bash

# Check if input file exists
if [ ! -f "$1" ]; then
    echo "Error: Input file does not exist"
    exit 1
fi

# check if file 2 exist
if [ ! -f "$2" ]; then
    echo "Error = File $2 not found."
    exit 1
fi

echo "full_name,age,birthday,birthday_GMT,league,season,position,Current Club,minutes_played_overall,minutes_played_home,minutes_played_away,nationality,appearances_overall,appearances_home,appearances_away,goals_overall,goals_home,goals_away,assists_overall,assists_home,assists_away,penalty_goals,penalty_misses,clean_sheets_overall,clean_sheets_home,clean_sheets_away,conceded_overall,conceded_home,conceded_away,yellow_cards_overall,red_cards_overall,goals_involved_per_90_overall,assists_per_90_overall,goals_per_90_overall,goals_per_90_home,goals_per_90_away,min_per_goal_overall,conceded_per_90_overall,min_per_conceded_overall,min_per_match,min_per_card_overall,min_per_assist_overall,cards_per_90_overall,rank_in_league_top_attackers,rank_in_league_top_midfielders,rank_in_league_top_defenders,rank_in_club_top_scorer" >> "$2"

# Get top 10 players with highest goals_overall
top_goals=$(awk -F, 'NR>1{print $16}' "$1" | sort -rn | uniq | head -n 10)

#echo $top_goals
# Loop through top 10 goal scores and find corresponding players
for goal in $top_goals; do
    # Check if goal is not empty
    if [ -n "$goal" ]; then
        players=$(awk -F, -v goal="$goal" 'NR>1{if($16 == goal) print}' "$1")
        echo "$players" >> "$2"
        #echo $players

    fi
done

#to run
# chmod +x top_goals_scorer.sh
#./top_goals_scorer.sh input.csv out3.csv