#!/bin/bash

# Check if two file names are provided
if [ $# -ne 2 ]; then
    echo "Usage: comm.sh file1 file2"
    exit 1
fi

# Check if the first file exists
if [ ! -f "$1" ]; then
    echo "Error: $1 does not exist"
    exit 1
fi

# Check if the second file exists
if [ ! -f "$2" ]; then
    echo "Error: $2 does not exist"
    exit 1
fi

# Read the first file line by line
# ||[[ -n "$line1" ]] at the end of the read command is used to also check if the last line of the file is empty 
while read -r line1||[[ -n "$line1" ]]; do
    # Ignore empty lines
    if [[ "$line1" =~ ^[[:space:]]*$ ]]; then
        continue
    fi

    # Read the second file line by line
    while read -r line2||[[ -n "$line2" ]]; do
        # Ignore empty lines
        if [[ "$line2" =~ ^[[:space:]]*$ ]]; then
            continue
        fi

        # Check if the lines match
        if [[ "$line1" == "$line2" ]]; then
            echo "$line1"
        fi
    done < "$2"
done < "$1"
